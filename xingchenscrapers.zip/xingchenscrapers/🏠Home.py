# -*- coding: utf-8 -*-
"""
Created on Mon Jun 20 09:55:50 2022

@author: zhangliyao
"""

import streamlit as st

def main():
    st.sidebar.title("关于")
    st.sidebar.info(
    """
    GitHub repository: <https://github.com/judd147/xingchenscrapers>
    
    作者: 张力铫
    """
    )
    st.title('足球比赛自动化项目')
    st.caption('')
    st.header('项目简介')
    st.markdown('Streamlit is **_really_ cool**.')
    
    
    
    
    

if __name__ == "__main__":
    main()