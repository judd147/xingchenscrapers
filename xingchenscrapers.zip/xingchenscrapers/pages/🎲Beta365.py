# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 15:18:11 2023

@author: zhangliyao
betting simulator with Streamlit
"""


import time
import pandas as pd
import streamlit as st
from PIL import Image
from datetime import datetime
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.edge.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException

def main():
    st.set_page_config(
    page_title="Beta365",
    page_icon=Image.open('pages/bet365.jpg')
    #initial_sidebar_state="expanded"
    )
    st.title("beta365")
    
    with st.form("user_input"):
        source = st.radio("选择当前设备", ["PC","Company"], help='不同设备的webdriver路径可能会不同')
        if source == 'PC':
            driver_path = r'D:\edgedriver_win64\msedgedriver.exe'
        elif source == 'Company':
            driver_path = r'D:\EdgeDriver\msedgedriver.exe'
        logged = st.checkbox('是否登录', value=True)
    
        submitted = st.form_submit_button("运行")
        
    if submitted:
        driver = webdriver.Edge(service=Service(executable_path=driver_path))
        driver.implicitly_wait(10)
        driver.get("https://www.bet365.com/")
        time.sleep(10)
        
        #登录
        if logged:
            init_login = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME,'hm-MainHeaderRHSLoggedOutWide_LoginContainer')))
            init_login.click()
            st.success('已点击登录')
            
            username = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME,'lms-StandardLogin_Username')))
            username.send_keys("zhanl217")
            password = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME,'lms-StandardLogin_Password')))
            password.send_keys("judd147t") #encryption required
            login = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME,'lms-LoginButton')))
            login.click()
            st.success('登录成功！')
            
            #What's next?
            #1.建立球队名称字典
            #2.需要点击哪些元素进入赛前投注界面
            #3.亚盘+胜平负元素
            
            
        else:
            st.success('网络连接成功！')
        
        time.sleep(30)
             
if __name__ == "__main__":
    main()